# Complete reproducibility archive

Associated article: Cultivar-dependent transcriptional responses of lychee to Peronophythora litchii: a registered genome-wide analysis
Author: Eric Zhuang
Package date: 2026-09-05

This single archive contains the complete electronic research materials for the
article:

- data/supplementary_tables: Supplementary Tables S1-S18;
- data/supplementary_figures: Figures S1-S3 in PDF and 300-DPI PNG formats;
- data/figure_source_data: tab-delimited source data for the main and
  supplementary analytical figures; and
- code/analysis: Snakemake workflows, Python and R scripts, configurations,
  metadata, synthetic fixtures, regression tests and environment specifications.

Raw sequencing reads and large reference resources are not redistributed. Their
public accessions and identifiers are given in the manuscript. All materials are
supplied under CC BY 4.0; third-party software retains its own licence.

MANIFEST.tsv records the byte size and SHA-256 digest of every other file in this
archive.
