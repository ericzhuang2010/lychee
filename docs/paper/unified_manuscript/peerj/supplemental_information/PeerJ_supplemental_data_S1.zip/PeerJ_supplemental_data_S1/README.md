# PeerJ Supplemental Data S1

Associated article: Cultivar-dependent transcriptional responses of lychee to Peronophythora litchii: a registered genome-wide analysis
Author: Eric Zhuang
Package date: 2026-09-06

This archive contains the complete supplemental and reproducibility material:

- data/supplementary_tables: Supplementary Tables S1-S18 (S16 has parts a and b);
- data/supplementary_figures: Figures S1-S3 in PDF and 300-DPI PNG formats;
- data/figure_source_data: tab-separated source data for all main and
  supplementary analytical figures; and
- code/analysis: Snakemake workflows, Python and R scripts, configurations,
  metadata, synthetic fixtures, regression tests, and environment specifications.

Raw sequencing reads and large reference resources are not redistributed. Their
public accessions and identifiers are given in the manuscript. The supplementary
tables, figures, and figure source data are also archived at https://doi.org/10.5281/zenodo.22240717; this
submission archive additionally contains the analysis code and workflows.

MANIFEST.tsv records the byte size and SHA-256 digest of every other file in this
archive. The materials are supplied under CC BY 4.0; third-party software retains
its own license.
