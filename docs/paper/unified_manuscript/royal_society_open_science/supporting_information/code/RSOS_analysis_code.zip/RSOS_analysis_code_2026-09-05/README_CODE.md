# Analysis-code electronic supplementary material

Associated article: Cultivar-dependent transcriptional responses of lychee to
Peronophythora litchii: a registered genome-wide analysis

Author: Eric Zhuang
Package date: 2026-09-05

This archive contains the analytical source code supplied for editorial and
peer-review verification. It includes the Snakemake workflows, Python and R
analysis scripts, configuration files, environment specifications, metadata,
synthetic fixtures and regression tests used for the study. Manuscript-formatting
and release-packaging utilities are excluded because they do not generate the
reported statistics or analytical figures.

Raw sequencing reads and large reference resources are not redistributed. Their
public accessions and identifiers are given in the manuscript. Frozen result
tables and figure source data are in the separate supplementary-data archive.

The main workflow entry points are analysis/workflow/Snakefile,
analysis/workflow/external_study.smk and analysis/workflow/finalize.smk. Software
requirements are recorded under analysis/envs and exact observed versions are
reported in Supplementary Table S17. Outcome-free regression tests are under
analysis/tests. The workflows expect the project-relative data and results paths
described in the manuscript and configuration files.

This code is submitted as electronic supplementary material. If the article is
accepted, it will be published under the journal's CC BY 4.0 supplementary-
material terms; third-party software retains its own licence.

MANIFEST.tsv records the byte size and SHA-256 digest of every other file in this
archive.
